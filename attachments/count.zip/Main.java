/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package  worksheet ;
import.java.util.Scanner;
public class count 
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner (System.in);
		System.out.println("Enter the no of times the loop should run");
		int n=obj.nextInt();
		int pos=0,neg=0,z=0;
		for(int i=0;i<n;i++)
		{
		    System .out.println("Enter the number");
		    int c= obj.nextInt();
		    if(c>0)
		    pos++;
		    else if(c<0)
		    neg++;
		    else
		    z++;
		}
		System .out.println("No of positive numbers"+pos);
	}
}
