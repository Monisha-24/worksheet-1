/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

package  worksheet.pkg1
{

import java.util.Scanner;
public class Worksheet1
{
public static void main(string[]  args)
{
Scanner obj = new Scanner(System.in);
system.out.println("Enter 3 nos");
int a=obj.nextInt();
int b=obj.nextInt();
int c=obj.nextInt();
if(a>b && a>c)
system.out.println("A is greatest");
else if (b>a && b>c)
system.out.println("B is greatest");
else
system.out.println("C is greatest");
}
}
}
