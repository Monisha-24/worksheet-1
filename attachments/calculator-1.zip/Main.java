/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet ;
import java.util.Scanner;
public class calculator
{
	public static void main(String[] args) {
	    int a=10,b=3;
	    Scanner obj=new Scanner(System.in);
	    char c= obj.next().chat At(0);
		System.out.println("enter + for addition,- for subtraction,* for multiplication,/ gor division");
		switch(c)
		{
		    case'+':
		        System .out.println(a+b);
		        break;
		    case'-':
		        System .out.println (a-b);
		        break;
		        case'*':
		            System.out.println(a*b);
		            break;
		            case'/':
		                System .out.println (a/b);
		                break;
		                default :
		                System .out.println ("Invalid ");
		}
	}
}
