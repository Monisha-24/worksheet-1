/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet ;
import .java.util .Scanner;
public class   peimeter
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner (System.in);
		System.out.println("enter the value of a:");
		int a= obj.nextInt();
		System .out.println("perimeter is"+(4*a));
	}
}
