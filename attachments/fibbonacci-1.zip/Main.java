/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet;
import java.util.*
public class Worksheet
{
	public static void main(String[] args)
	{
	   Scanner obj=?new Scanner (System .in);
	 System .out.println*"Enter a limit:");
	 int n =obj.nextInt();
	 int a=0;
	 int b=1;
	 int i,c;
	 System .out.println("Fibonacci series:"+a+""+b);
	 for(i=2;i<n;i++)
	 {
	     c=a+b;
	     System.out.println(""+C);
	     a=b;
	     b=c;
	 }
	 
	
		
	}
}
