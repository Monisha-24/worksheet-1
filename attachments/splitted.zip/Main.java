/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package Worksheet ;
import java.utill.Scanner;
public class splitted
{
	public static void main(String[] args) {
		System.out.println("Enter n value");
		int n = obj.nextInt*);
		int d=0;
		int a[i]= newint[10];
		int i=0;
		while(n>0)
		{
		    d=n%10;
		    a[i]=d;
		    n=n/10;
		    i++;
		}
		System .out.println("Splitted digits");
		for(int j =i-1;j>=0;j--)
		System .out.println(a[j]);
	}
}
