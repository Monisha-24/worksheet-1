/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package Worksheet.pkg1;
import.java.util.Scanner;
public class zeroto9
{
	public static void main(String[] args) {
	    Scanner obj=Scanner(System.i);
		System.out.println("Press key");
		int a= obj.nextInt();
		switch(a)
		{
		   case 0:
		    case 1:
		      case 2:
		        case 3:
		            case 4:
		                case 5:
		                    case 6:
		                        case 7:
		                            case 8:
		                                case 9:
		                                    System .out.println(:you pressed:"+a);
		                                    break;
		                                    default :
		                                    System .out.println("You pressed a invalid key")
		}
	}
}
