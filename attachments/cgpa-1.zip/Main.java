/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*************************************************************************
* package cgpa.pkg1

{
    import java.util.Scanner 
    public class cgpa
   public static void main (string[]args)
{
Scanner obj=new Scanner (System.in);
double m[]= new double [10];
double c[]= new double [10];
double sum=0,csum=0;
int i;
System.out.println("Enter no of subjects");
int n=obj.nextInt();
for(i=0;i<n;i++)
{System.out.println("Enter Grade and Credit for"+(i+1)+"Subject" );
m[i]=obj.nextDouble();
c[i]=obj.nextDouble();
sum=sum+m[i]*c[i];
csum=csum+c[i];
}
System .out.println("CGPA.."+(sum/csum));
}
}
