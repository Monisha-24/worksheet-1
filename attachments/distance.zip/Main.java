/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet;
import java.utill.Scanner ;
public class distance
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner(System.in);
		System.out.println("Enter the x1,x2,y1,y2");
		float x1= obj.nextFloat();
		float x2= obj.nextFloat();
		float y1= obj.nextFloat();
		float y2= obj.nextFloat();
		double d=Math.sqrt(((Math.pow((x2-x1),2))+(Math.pow((y2-y1),2)));
		System .out.println (""+d)
	}
}
