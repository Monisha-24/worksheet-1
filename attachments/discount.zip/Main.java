/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet ;
import .java util.Scanner ;
public class discount 
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner(System.in);
		System.out.println("Enter the original Amt of the project ");
		floatdis= obj.nextInt();
		double d=amt-((dis/100)*amt);
		System .out.println("He total amount to be paid ");
	}
}
