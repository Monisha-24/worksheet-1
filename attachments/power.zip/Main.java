/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet.pkg1;
import java.until.Scanner;
public class power
{
	public static void main(String[] args) {
		int n=3,p=2;
		System.out.println("Answe is");
		System.out.println(Math.pow(n,p));
	}
}
