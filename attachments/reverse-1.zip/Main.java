/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package reverse.pkg1
{
    import java.until.Scanner;

public class reverse
{
	public static void main(String[] args) 
	{
		Scanner obj = new Scaner(System.in);
		int n =obj.nextInt();
		int a[]=new int[10];
		int i;
		for(i=0;i<n;i++)
		{
		    a[i]=obj.nextInt();
		}
		for(i=n-1;i>=0;i--)
		{
		    System .out.println(a[i]);
		}
	}
}
}