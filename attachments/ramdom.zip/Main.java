/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
package worksheet .pkg1;
import java .utility.Scanner
public class random
{
	public static void main(String[] args) {
		System.out.println((int)Math.random()*100);
	}
}
